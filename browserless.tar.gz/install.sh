#!/bin/bash

# Update and Upgrade 

apk update && apk upgrade

#install nodejs and npm

apk add nodejs npm

#install chrome
npm install puppeteer && npx puppeteer browsers install chrome

# Install dependency

apk add nss cups-libs dbus expat fontconfig gcc gdk-pixbuf glib gtk+3.0 nspr pango libstdc++ libx11 libxcb libxcomposite libxcursor libxdamage libxext libxfixes libxi libxrandr libxrender libxtst ca-certificates ttf-freefont chromium libx11-dev xdg-utils wget mesa-dev


#how to run
echo "done!"

echo "run 'node index.js' to start."